package com.example.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<UserEntity> getAllUser() 
	{
		/* return userRepository.findAll(); */
		List<UserEntity> users = userRepository.findAll();
	    System.out.println("Users fetched from DB: " + users);
	    return users;
	}

	@Override
	public Optional<UserEntity> getUserById(Long id) 
	{
		return userRepository.findById(id);
	}

	@Override
	public UserEntity createUser(UserEntity userEntity) 
	{
		return userRepository.save(userEntity);
	}

	@Override
	public UserEntity updateUser(Long id, UserEntity userEntity) 
	{
		return userRepository.save(userEntity);
	}

	@Override
	public void deleteUser(Long id) 
	{
		userRepository.deleteById(id);
	}
	
}
