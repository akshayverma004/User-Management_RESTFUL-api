package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.UserEntity;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/api/userEntity/")
public class UserController 
{
	@Autowired
	private UserService userService;
	
	@GetMapping(value="getAllUsers", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserEntity> getAllUser()
	{
		return userService.getAllUser();
	}
	
	@GetMapping(value="{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Optional<UserEntity> getUserById(@PathVariable Long id)
	{
		return Optional.of(userService.getUserById(id).get());
	}
	@PostMapping(value="creatingUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public UserEntity createUser(@RequestBody UserEntity userEntity) 
	{
		return userService.createUser(userEntity);
	}
	@PutMapping(value="{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public UserEntity updateUser(@PathVariable Long id, @RequestBody UserEntity userEntity) 
	{
		return userService.updateUser(id, userEntity);
		
	}
	@DeleteMapping(value="{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String deleteUser(@PathVariable Long id) 
	{
		userService.deleteUser(id);
		return "User has been deleted successfully";
	}
}
