package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.UserEntity;

public interface UserService 
{
	List<UserEntity>getAllUser();
	Optional<UserEntity>getUserById(Long id);
	UserEntity createUser(UserEntity userEntity);
	UserEntity updateUser(Long id, UserEntity userEntity);
	void deleteUser(Long id);		
}
